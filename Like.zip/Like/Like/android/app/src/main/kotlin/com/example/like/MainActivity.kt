package com.example.like

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
